from views import view  

if __name__ == '__main__':
    view.main()

    # Tendo em conta que "deve ser indicado em comentário quais são os requi-
    #   sitos do programa e qual o resultado esperado", faço um breve comentário do laboratório 02:
    # Como basicamente só tivemos que desenvolver o código no "view.py", o "controller.py" ficou vazio.
    # A ideia foi importarmos as funções já feitas pela professora e apenas foi necessário tratar das condições IF e ELSE, bem como das mensagens de saída.
    # Primeiramente defini uma função "main", como sempre tenho feito.
    # Do "RPI" até ao "RPII", importei a respetiva função.A cada país registado, o programa corre uma lista dos países registados (utilizando a função "traverse_list()").
    # O "VNE" faz correr o número de elementos da lista.
    # No "VP" vericamos se um país se encontra na lista e fazemos correr a mensagem de acordo com cada situação.
    # No "EPE" e "EUE" eliminamos o país conforme pedido no enunciado.
    # No "EP" eliminamos o país de acordo com o nome registado. O programa vai analisar se esse nome se encontra na lista de países.
    # Irá sair uma mensagem conforme o facto do país se encontrar ou não, na lista de países.
     